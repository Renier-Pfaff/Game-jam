extends Control

@onready var anim_sprite = $AnimatedSprite2D
@onready var label1 = $VBoxContainer/lblGameOver
@onready var label2 = $VBoxContainer/lblRetry
#@onready var game_over_sprite = $CanvasLayer/AnimatedSprite2D

# Called when the node enters the scene tree for the first time.
func _ready():
	if Input.is_action_just_pressed("Right"):
		GameManagerr.Game_Over()
	# Start the animation as soon as this scene appears
	#anim_sprite.play("GameOverAni")
	
	# Wait until the 'animation_finished' signal is sent
	await anim_sprite.animation_finished
	
	# Now show the labels!
	label1.visible = true
	label2.visible = true
	pass # Replace with function body.

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass
