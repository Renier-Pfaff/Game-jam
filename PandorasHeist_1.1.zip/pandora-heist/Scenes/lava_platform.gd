extends Node2D

var speed = 800 # Match this to your background scroll speed

func _process(delta):
	# Move the spike to the left
	position.x -= speed * delta

	# If it goes off screen to the left, delete it to save memory
	if position.x < -800:
		queue_free()
# Called when the node enters the scene tree for the first time.


func _on_area_2d_body_entered(body: Node2D) -> void:
	if body.is_in_group("Player"):
		GameEvents.player_hit_lava.emit()
	pass # Replace with function body.
	pass # Replace with function body.
