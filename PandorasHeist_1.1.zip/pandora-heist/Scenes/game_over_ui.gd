extends CanvasLayer

@onready var game_over_sprite: AnimatedSprite2D = $GameOverSprite


func GameOver():
	# 1. Show the sprite
	game_over_sprite.visible = true
	
	# 2. Play the animation you made
	game_over_sprite.play("GameOverAni")
	
	# 3. Optional: Pause the rest of the game
	get_tree().paused = true

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	# Make sure it's hidden when the game starts
	game_over_sprite.visible = false
	GameEvents.player_hit_spikes.connect(GameOver)
	GameEvents.player_hit_lava.connect(GameOver)
	
	if Input.is_action_just_pressed("Right"):
		GameOver()
	pass # Replace with function body.



# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass
