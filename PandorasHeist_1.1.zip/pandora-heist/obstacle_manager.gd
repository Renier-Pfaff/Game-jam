extends Node2D

# This allows you to "drop" your Spike.tscn into the Inspector
@export var spike_template: PackedScene 
@export var lava_template: PackedScene
@export var Platform_template: PackedScene


func _on_obstacle_timer_timeout() -> void:
	# 1. Create a copy of the spike
	var new_spike = spike_template.instantiate()
	var lava_sprite = lava_template.instantiate()
	var lava_platform = Platform_template.instantiate()
	
	var randomNum = randi_range(1, 3)
	
	# 2. Set its position to the Marker2D's position
	new_spike.global_position = $Spawnpoint.global_position
	lava_sprite.global_position = $Spawnpoint.global_position
	lava_platform.global_position = $Spawnpoint.global_position
	
	lava_sprite.global_position.y -= 12
	lava_platform.global_position.y -= 12
	
	# 3. Add it to the level
	if randomNum == 1:
		get_parent().add_child(new_spike)
	elif randomNum == 2:
		get_parent().add_child(lava_platform)
	else:
		get_parent().add_child(lava_sprite)
	pass # Replace with function body.
