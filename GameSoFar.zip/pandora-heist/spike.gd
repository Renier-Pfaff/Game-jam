extends Area2D

var speed = 800 # Match this to your background scroll speed

func _process(delta):
	# Move the spike to the left
	position.x -= speed * delta

	# If it goes off screen to the left, delete it to save memory
	if position.x < -800:
		queue_free()


func _on_body_entered(body: Node2D) -> void:
	if body.is_in_group("Player"):
		GameManagerr.Game_Over()
	pass # Replace with function body.
