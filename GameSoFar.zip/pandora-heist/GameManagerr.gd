extends Node
@onready var game_over_sprite: AnimatedSprite2D = $GameOverUI/AnimatedSprite2D

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	#get.tree().change_scene_to_file("res://Scenes/level_1.tscn")
	# Make sure it's hidden when the game starts
	game_over_sprite.visible = false
	pass # Replace with function body.
	
#func Game_Over():
	#get_tree().change_scene_to_file("res://Scenes/Game_Over.tscn")
func Game_Over():
	# 1. Show the sprite
	game_over_sprite.visible = true
	
	# 2. Play the animation you made
	game_over_sprite.play("your_animation_name")
	
	# 3. Optional: Pause the rest of the game
	get_tree().paused = true
# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass
