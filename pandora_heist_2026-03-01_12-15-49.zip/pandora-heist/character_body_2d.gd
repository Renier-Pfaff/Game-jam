extends CharacterBody2D


const SPEED = 300.0
const JUMP_VELOCITY = -750.0


func _physics_process(delta: float) -> void:
	# Add the gravity.
	if not is_on_floor():
		if velocity.y > 0: # Player is falling
			velocity.y += get_gravity().y * delta * 2.5
			# Set falling animation
			
		else: # Player is moving upwards
			velocity.y += get_gravity().y * delta * 2.0
		#velocity += get_gravity() * delta * 2.0
		# Set rise animation

	# Handle jump.
	if Input.is_action_just_pressed("Jump") and is_on_floor():
		velocity.y = JUMP_VELOCITY
		# Set jump animation
		# Play jump sound

	# Get the input direction and handle the movement/deceleration.
	# As good practice, you should replace UI actions with custom gameplay actions.
	#var direction := Input.get_axis("ui_left", "ui_right")
	#if direction:
		#velocity.x = direction * SPEED
	#else:
		#velocity.x = move_toward(velocity.x, 0, SPEED)

	move_and_slide()
