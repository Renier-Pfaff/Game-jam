extends AnimatedSprite2D


# Called when the node enters the scene tree for the first time.
@onready var ninja_sprite: AnimatedSprite2D = $NinjaSprite
func _ready() -> void:
	#if ninja_sprite:
		#ninja_sprite.play("ninjaRunning")
	#if
	play("ninjaRunning")
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass
