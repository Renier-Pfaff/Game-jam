extends Node2D

# This allows you to "drop" your Spike.tscn into the Inspector
@export var spike_template: PackedScene 

func _on_obstacle_timer_timeout() -> void:
	# 1. Create a copy of the spike
	var new_spike = spike_template.instantiate()
	
	# 2. Set its position to the Marker2D's position
	new_spike.global_position = $Spawnpoint.global_position
	
	# 3. Add it to the level
	get_parent().add_child(new_spike)
	pass # Replace with function body.
