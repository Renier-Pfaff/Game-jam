extends Camera2D

#func _physics_process(delta: float) -> void:
	#if Input.is_action_pressed("Left"):
		#global_position += Vector2(-10, 0)
	#if Input.is_action_pressed("Right"):
		#global_position += Vector2(10, 0)


# Called when the node enters the scene tree for the first time.
@onready var ninja_sprite: AnimatedSprite2D = $NinjaSprite
func _ready() -> void:
	if ninja_sprite:
		ninja_sprite.play("ninjaRunning")
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	
	pass
