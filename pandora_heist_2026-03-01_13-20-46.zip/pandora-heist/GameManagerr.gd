extends Node


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	#get.tree().change_scene_to_file("res://Scenes/level_1.tscn")
	pass # Replace with function body.
	
func Game_Over():
	get_tree().change_scene_to_file("res://Scenes/Game_Over.tscn")
	


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass
